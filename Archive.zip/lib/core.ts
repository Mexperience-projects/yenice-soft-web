// localhost server for programing
// export const SERVER_URL = "http://localhost:8000";
// server url on docker
export const SERVER_URL = "http://104.248.21.212";
// server programing
// export const SERVER_URL = "http://192.168.118.130:8001";
