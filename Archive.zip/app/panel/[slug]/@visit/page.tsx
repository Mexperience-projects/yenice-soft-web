import Visit from "@/app/panel/[slug]/@visit/visit";

export default function () {
  return (
    <main>
      <Visit />
    </main>
  );
}
