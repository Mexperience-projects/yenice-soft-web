import Visit from "@/app/panel/[slug]/@payments/payments";

export default function () {
  return (
    <main>
      <Visit />
    </main>
  );
}
