import Visit from "@/app/panel/[slug]/@clients/clients";

export default function () {
  return (
    <main>
      <Visit />
    </main>
  );
}
