import Services from "@/app/panel/[slug]/@services/services";

export default function () {
  return (
    <main>
      <Services />
    </main>
  );
}
