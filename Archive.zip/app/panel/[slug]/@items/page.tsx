import Items from "@/app/panel/[slug]/@items/items";

export default function () {
  return (
    <main>
      <Items />
    </main>
  );
}
